<html>
<head>
<title>Main Login Page</title>
<link href="main.css" rel="stylesheet" type="text/css">
<style>
input[type=text], select, textarea {
  width: 100%;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 6px;
  resize: vertical;
}
</style>
</head>
<body>
<div id="main" >
<div id="centercontent">


<div id="form1" style="background-color:white;margin:10px;height:663px">
<h1 class="commuter" style="text-align:left;margin:10px;">CONTACT US</h1>
<div style="width:50%;float:left;background:#b3ffff;">




<h1 class="commuter" style="text-align:left;margin:10px;">Commuter Connect</h1>
<p style="margin:10px;">Palvi Sharma<br/>
Lambton College Toronto<br/>
647-(516)-(8950)</p>
<img src="images/contact.png" height="70" style="width:96%;margin:2%"/>
</div>
<div style="width:50%;float:left;background:#b3ffff;">



<div class="container">
  <form action="savecontact.php" height="733px" >
    <label for="fname">Email</label><br/>
    <input type="text" id="fname" name="email" class="email" placeholder="Your name.." style="width:293px;"><br/>


    <label for="subject">Message</label><br/>
    <textarea id="subject" name="msg" placeholder="Write something.." style="height:55px;width:293px;"></textarea>
    <input type="submit" value="Submit" style="margin-left:0px;width:90px;margin-top:10px;">
  </form>
</div>


</div>




<div class="mapouter" style="margin:10px;"><div class="gmap_canvas">
<iframe width="600" height="800" id="gmap_canvas" 
src="https://maps.google.com/maps?q=lambton%20college%20torront&t=&z=13&ie=UTF8&iwloc=&output=embed"
 frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
 <a href="https://www.pureblack.de">webseite erstellen lassen</a>
 </div>
 <style>.mapouter{text-align:right;height:500px;width:580px;}
 .gmap_canvas {overflow:hidden;background:none!important;height:430px;width:585px;}
 </style></div>



</div>



</div>



</div>
</body>
</html>




